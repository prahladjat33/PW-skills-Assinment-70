import { CustomRoute } from "./Customroutes/CustomRoutes";


function App() {
  return (
   <CustomRoute/>
  );
}

export default App;
